import { Mail, MapPin, Phone } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-32 bg-zinc-950 text-white border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-5xl lg:text-7xl font-black mb-4 tracking-tight">Get In Touch</h2>
        <p className="text-lg text-gray-400 mb-16 max-w-2xl">
          Have a project in mind or just want to chat? I'd love to hear from you!
        </p>
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="bg-white p-3">
                <Mail className="text-black" size={24} />
              </div>
              <div>
                <h3 className="text-xl mb-1 text-white font-bold">Email</h3>
                <a
                  href="mailto:alex@example.com"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  alex@example.com
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-white p-3">
                <Phone className="text-black" size={24} />
              </div>
              <div>
                <h3 className="text-xl mb-1 text-white font-bold">Phone</h3>
                <a
                  href="tel:+1234567890"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  +1 (234) 567-8900
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-white p-3">
                <MapPin className="text-black" size={24} />
              </div>
              <div>
                <h3 className="text-xl mb-1 text-white font-bold">Location</h3>
                <p className="text-gray-400">San Francisco, CA</p>
              </div>
            </div>
          </div>
          <form className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-white mb-2 uppercase text-sm tracking-wider">
                Name
              </label>
              <input
                type="text"
                id="name"
                className="w-full px-4 py-3 border border-white/20 bg-black text-white focus:outline-none focus:border-white transition-colors"
                placeholder="Your name"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-white mb-2 uppercase text-sm tracking-wider">
                Email
              </label>
              <input
                type="email"
                id="email"
                className="w-full px-4 py-3 border border-white/20 bg-black text-white focus:outline-none focus:border-white transition-colors"
                placeholder="your@email.com"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-white mb-2 uppercase text-sm tracking-wider">
                Message
              </label>
              <textarea
                id="message"
                rows={5}
                className="w-full px-4 py-3 border border-white/20 bg-black text-white focus:outline-none focus:border-white transition-colors"
                placeholder="Your message..."
              />
            </div>
            <button
              type="submit"
              className="w-full bg-white text-black py-4 hover:bg-gray-200 transition-colors uppercase tracking-wider font-semibold"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}