import { Github, Linkedin, Mail } from "lucide-react";
import { motion } from "motion/react";

export function Footer() {
  return (
    <footer className="bg-black text-white py-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h3 className="text-2xl mb-2 font-bold tracking-wider">
              <span className="text-white">
                ALEX JOHNSON
              </span>
            </h3>
            <p className="text-gray-400">
              Full Stack Developer & Designer
            </p>
          </div>
          <div className="flex gap-6">
            <motion.a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ y: -3 }}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <Github size={24} />
            </motion.a>
            <motion.a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ y: -3 }}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <Linkedin size={24} />
            </motion.a>
            <motion.a
              href="mailto:alex@example.com"
              whileHover={{ y: -3 }}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <Mail size={24} />
            </motion.a>
          </div>
        </div>
        <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-400">
          <p>© 2026 Alex Johnson. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}