import { Github, Linkedin, Mail, ArrowDown } from "lucide-react";
import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.1]);

  // Stagger animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  };

  const letterVariants = {
    hidden: { 
      opacity: 0, 
      y: 100,
      rotateX: -90,
    },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        duration: 0.8,
        ease: [0.6, 0.01, 0.05, 0.95],
      },
    },
  };

  const imageVariants = {
    hidden: { 
      opacity: 0,
      scale: 1.2,
      y: 100,
    },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: {
        duration: 1.2,
        delay: 0.5,
        ease: [0.6, 0.01, 0.05, 0.95],
      },
    },
  };

  const lineVariants = {
    hidden: { scaleX: 0 },
    visible: {
      scaleX: 1,
      transition: {
        duration: 1,
        delay: 1.5,
        ease: [0.6, 0.01, 0.05, 0.95],
      },
    },
  };

  const words = ["CREATIVE", "PORTFOLIO"];

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen bg-black text-white overflow-hidden pt-20"
    >
      {/* Animated grid background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)`,
          backgroundSize: '100px 100px',
        }} />
      </div>

      {/* Gradient overlay */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black"
        style={{ opacity }}
      />

      <motion.div
        style={{ opacity }}
        className="relative z-10 min-h-screen flex items-center"
      >
        <div className="max-w-[1600px] mx-auto px-6 lg:px-12 w-full py-20">
          {/* Top Info */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex justify-between items-start mb-12 text-sm"
          >
            <div className="text-gray-400">
              <div>DECEMBER / 2025</div>
            </div>
            <div className="text-right text-gray-400">
              <div>ALEX JOHNSON</div>
            </div>
          </motion.div>

          {/* Main content */}
          <div className="relative">
            {/* Large background text */}
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="relative"
            >
              {words.map((word, wordIndex) => (
                <div
                  key={wordIndex}
                  className="flex overflow-hidden"
                  style={{ marginBottom: wordIndex === 0 ? '-0.15em' : '0' }}
                >
                  {word.split('').map((letter, letterIndex) => (
                    <motion.span
                      key={letterIndex}
                      variants={letterVariants}
                      className="text-[12vw] lg:text-[14vw] xl:text-[16vw] font-black leading-none tracking-tighter text-white/10"
                      style={{
                        transformStyle: 'preserve-3d',
                        y: textY,
                      }}
                    >
                      {letter}
                    </motion.span>
                  ))}
                </div>
              ))}
            </motion.div>
          </div>

          {/* Bottom section */}
          <div className="grid lg:grid-cols-2 gap-12 mt-24">
            {/* Left description */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 1.8 }}
              className="space-y-6"
            >
              <h2 className="text-3xl lg:text-4xl xl:text-5xl font-bold">
                Full Stack Developer
                <br />
                <span className="text-gray-400">& Designer</span>
              </h2>
              <p className="text-gray-400 leading-relaxed text-lg">
                I create beautiful, functional web experiences that solve real
                problems. Passionate about clean code, intuitive design, and
                building products that make a difference. With 5+ years of
                experience, I bring ideas to life with precision and creativity.
              </p>
              
              {/* Decorative line */}
              <motion.div
                variants={lineVariants}
                initial="hidden"
                animate="visible"
                className="h-px bg-gradient-to-r from-white via-gray-600 to-transparent origin-left"
              />
            </motion.div>

            {/* Right info */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 2 }}
              className="space-y-8"
            >
              <p className="text-gray-400 leading-relaxed text-lg">
                Specializing in React, Node.js, and modern web technologies. I
                transform complex problems into elegant solutions, focusing on
                performance, accessibility, and user experience. Every project
                is an opportunity to push boundaries and create something
                exceptional.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-wrap gap-4">
                <motion.a
                  href="#contact"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-white text-black px-8 py-4 rounded-none text-sm font-semibold hover:bg-gray-200 transition-colors uppercase tracking-wider"
                >
                  Get in Touch
                </motion.a>
                <motion.a
                  href="#projects"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="border border-white text-white px-8 py-4 rounded-none text-sm font-semibold hover:bg-white hover:text-black transition-colors uppercase tracking-wider"
                >
                  View Work
                </motion.a>
              </div>

              {/* Social Links */}
              <div className="flex gap-6 pt-4">
                <motion.a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -3 }}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <Github size={24} />
                </motion.a>
                <motion.a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -3 }}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <Linkedin size={24} />
                </motion.a>
                <motion.a
                  href="mailto:alex@example.com"
                  whileHover={{ y: -3 }}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <Mail size={24} />
                </motion.a>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 2.5 }}
        style={{ opacity }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center gap-3 text-gray-400"
        >
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <ArrowDown size={20} />
        </motion.div>
      </motion.div>

      {/* Side decoration */}
      <motion.div
        initial={{ scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ duration: 1, delay: 2.2, ease: [0.6, 0.01, 0.05, 0.95] }}
        className="absolute right-12 top-32 bottom-32 w-px bg-gradient-to-b from-transparent via-white/20 to-transparent origin-top hidden lg:block"
      />
    </section>
  );
}