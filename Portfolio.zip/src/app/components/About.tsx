export function About() {
  return (
    <section id="about" className="py-32 bg-black text-white border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-5xl lg:text-7xl font-black mb-16 tracking-tight">About Me</h2>
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <p className="text-lg text-gray-400 mb-6">
              I'm a passionate full-stack developer with 5+ years of experience
              building web applications. I specialize in creating seamless user
              experiences with modern technologies.
            </p>
            <p className="text-lg text-gray-400 mb-6">
              My journey in tech started with a curiosity about how things work,
              and has evolved into a career where I get to solve complex
              problems and bring ideas to life every day.
            </p>
            <p className="text-lg text-gray-400">
              When I'm not coding, you can find me exploring new technologies,
              contributing to open source, or sharing knowledge through blog
              posts and mentoring.
            </p>
          </div>
          <div className="space-y-6">
            <div>
              <h3 className="text-xl mb-2 text-white">Experience</h3>
              <p className="text-gray-400">
                5+ years in web development, working with startups and
                established companies
              </p>
            </div>
            <div>
              <h3 className="text-xl mb-2 text-white">Education</h3>
              <p className="text-gray-400">
                B.S. in Computer Science, Minor in Design
              </p>
            </div>
            <div>
              <h3 className="text-xl mb-2 text-white">Focus Areas</h3>
              <p className="text-gray-400">
                User Experience, Performance Optimization, Accessibility, Modern
                Web Architecture
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}