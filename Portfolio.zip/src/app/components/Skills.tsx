import { Code, Database, Layers, Smartphone } from "lucide-react";

const skillCategories = [
  {
    title: "Frontend Development",
    icon: Code,
    skills: [
      "React & Next.js",
      "TypeScript",
      "Tailwind CSS",
      "HTML/CSS",
      "State Management",
      "Responsive Design",
    ],
  },
  {
    title: "Backend Development",
    icon: Database,
    skills: [
      "Node.js & Express",
      "PostgreSQL & MongoDB",
      "RESTful APIs",
      "GraphQL",
      "Authentication",
      "Cloud Services",
    ],
  },
  {
    title: "Design & UX",
    icon: Layers,
    skills: [
      "UI/UX Design",
      "Figma & Sketch",
      "Design Systems",
      "Prototyping",
      "User Research",
      "Accessibility",
    ],
  },
  {
    title: "Tools & Technologies",
    icon: Smartphone,
    skills: [
      "Git & GitHub",
      "Docker",
      "CI/CD",
      "Testing (Jest, Cypress)",
      "Agile Methodologies",
      "Performance Optimization",
    ],
  },
];

export function Skills() {
  return (
    <section id="skills" className="py-32 bg-black text-white border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-5xl lg:text-7xl font-black mb-4 tracking-tight">Skills & Expertise</h2>
        <p className="text-lg text-gray-400 mb-16 max-w-2xl">
          A comprehensive toolkit built through years of hands-on experience and
          continuous learning.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div
                key={index}
                className="bg-zinc-950 p-8 border border-white/10 hover:border-white/30 transition-all"
              >
                <div className="bg-white w-12 h-12 flex items-center justify-center mb-6">
                  <Icon className="text-black" size={24} />
                </div>
                <h3 className="text-xl mb-4 text-white font-bold">{category.title}</h3>
                <ul className="space-y-2">
                  {category.skills.map((skill, skillIndex) => (
                    <li key={skillIndex} className="text-gray-400 flex items-start">
                      <span className="text-white mr-2">—</span>
                      {skill}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}